# 🎮 Mob Control Player Matcher

Register yourself, explore global players, and send pings to make new allies in Mob Control.

🌍 Features:
- Register with in-game name, tier, region, timezone
- View players worldwide
- Click ping to notify another player
- View local time and country of other players before pinging
- Dark theme with responsive mobile-first design

---

👨‍💻 Made with 💡 by **Amrit Sahai**  
📧 Contact: [amritsahai117@gmail.com](mailto:amritsahai117@gmail.com)
